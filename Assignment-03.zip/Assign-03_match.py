import random
number = random.randint(1, 250)
print(number)
guess = int(input("enter score: "))
if (number-10) <= guess <= number:
    print("close by,you are true Indian fan!")
elif number < guess <= (number+10):
    print("you don't watch that match!:p")
else:
    print("very far try again!!")
